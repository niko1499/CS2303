//life.h Niko Gamarra

#ifndef LIFE_H
#define LIFE_H

#endif

