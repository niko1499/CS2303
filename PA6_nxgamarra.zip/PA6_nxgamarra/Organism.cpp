//============================================================================
// Name        : Organism.cpp
// Author      : Nikolas X. Gamarra
// Date		   : 2/22/17
// Version     : 1
// Copyright   : -
// Description : Organism Simulation
//============================================================================
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include <iostream>
#include <string>
#include <cstring>

#include "Organism.h"



//namespace Org{
/*
Organism::Organism(){

}*/
//}

void Ant::move(void) {
	//int moveDirection = rand() % 4; //generates 0, 1, 2, 3

}
void Ant::print(void){
	std::cout<<"o";
}
void Ant::replicate(void){

}
void DoodleBug::move(void) {

}
void DoodleBug::print(void){
	std::cout<<"x";
}
void DoodleBug::replicate(void){

}
